const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Todo = sequelize.define('Todo', {
  userId: {
    type: DataTypes.STRING,
    allowNull: false
  },
  text: {
    type: DataTypes.STRING,
    allowNull: false
  },
  completed: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  deadline: {
    type: DataTypes.DATE
  }
});

module.exports = Todo;
